#' @useDynLib GroupAssignment
#' @importFrom Rcpp evalCpp
#' @exportPattern "^[[:alpha:]]+"
NULL